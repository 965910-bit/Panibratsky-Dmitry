SCM Google Search Console connection

1. Extract the entire ZIP archive to a folder on your Windows computer.
2. Double-click Connect-Google.cmd.
3. Select the Desktop OAuth JSON file downloaded from Google.
4. Type ДА when asked, sign in to the Google account that owns scm-news.ru,
   and allow Search Console access in your browser.

The tool requires Python 3 and GitHub CLI (gh) authenticated to an account able
 to manage repository Actions secrets. It stores three Google OAuth values in
 GitHub Actions Secrets. It does not enable automation or submit a sitemap.
Do not send the JSON file, authorization code, or tokens in chat.
If an error occurs during secret creation, do not blindly rerun: some secrets
may already have been created. Report the non-secret error message instead.

For an external OAuth app in Testing mode Google may expire refresh tokens after
seven days. A durable production authorization requires a separate follow-up.
