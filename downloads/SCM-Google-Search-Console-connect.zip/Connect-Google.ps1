$ErrorActionPreference = 'Stop'
try {
    Write-Host 'SCM Search Console: connection setup'
    & gh auth status
    if ($LASTEXITCODE -ne 0) { throw 'GitHub CLI is not signed in.' }
    & py -3 --version
    if ($LASTEXITCODE -ne 0) { throw 'Python 3 is not available.' }
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = 'Select the Desktop OAuth JSON downloaded from Google'
    $dialog.Filter = 'Google OAuth JSON (*.json)|*.json'
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        Write-Host 'Cancelled. No changes were made.'
    } else {
        & py -3 "$PSScriptRoot\webmaster_google_connect.py" $dialog.FileName
        if ($LASTEXITCODE -ne 0) { Write-Host 'Connection was not completed; do not repeat without checking the message above.' }
    }
} catch {
    Write-Host 'Setup could not start. Check Python 3 and GitHub CLI access.'
}
Write-Host ''
Read-Host 'Press Enter to close'
