SCM Google Analytics reporting connection for Windows

1. Enable Google Analytics Data API in the same Google Cloud project.
   This is a separate API from the already-enabled Analytics Admin API.
2. Extract the entire ZIP and run Connect-GA4-reports.cmd.
3. Select the SAME Desktop OAuth JSON used earlier.
4. Type ДА, sign in to the Google account managing scm-news.ru in Analytics,
   and grant analytics.readonly for reports.

Requires Python 3 and GitHub CLI signed in with permission to set Actions secrets.
The helper stores separate SCM_GA4_REPORT_* GitHub secrets. It does not replace
Search Console or Analytics administration secrets, and does not change settings.
No credentials need to be pasted into chat. If saving fails, some secrets may
already have been saved; report the non-secret error instead of retrying blindly.
Google external OAuth in Testing mode may expire after seven days.
