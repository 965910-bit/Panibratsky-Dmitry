@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Connect-GA4-reports.ps1"
