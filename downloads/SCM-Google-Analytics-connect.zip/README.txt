SCM Google Analytics connection for Windows

1. Enable Google Analytics Admin API in the same Google Cloud project used for
   the Search Console client.
2. Extract the entire ZIP into a folder and run Connect-GA4.cmd.
3. Select the SAME Desktop OAuth JSON file you downloaded from Google earlier.
4. Type ДА, sign in to the Google account that manages scm-news.ru in Analytics,
   and grant the analytics.edit permission.

Requires Python 3 and GitHub CLI authenticated with access to Actions secrets.
The tool stores separate SCM_GA4_* GitHub Secrets and does not overwrite the
Search Console secrets, modify Google Analytics settings, or create goals.
If an error occurs while saving, some secrets might already exist: do not rerun
blindly, report the non-secret error instead. No credentials need to be pasted.
For an external Google OAuth app in Testing mode, refresh tokens may expire
in seven days; durable authorization requires a separate follow-up.
