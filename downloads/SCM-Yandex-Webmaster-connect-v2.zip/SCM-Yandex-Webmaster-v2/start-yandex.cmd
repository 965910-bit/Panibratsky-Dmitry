@echo off
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (echo Python launcher not found. & pause & exit /b 1)
where gh >nul 2>&1
if errorlevel 1 (echo GitHub CLI not found. & pause & exit /b 1)
py -3 -X utf8 webmaster_yandex_code_connect.py
set "RESULT=%ERRORLEVEL%"
echo.
pause
exit /b %RESULT%
